<template>
  <button v-if="!isAuthenticated" @click="submitLogin()">Login Page Placeholder Here</button>
</template>
<script src="./LoginView.ts" />


<style src="./LoginView.scss" />
