<template>
  <h1>This is an about page</h1>
</template>
