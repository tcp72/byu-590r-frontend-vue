export default {
    name: 'AboutView'
}