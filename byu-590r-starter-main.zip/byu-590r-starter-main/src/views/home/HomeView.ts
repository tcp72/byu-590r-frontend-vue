
export default {
    name: 'HomeView',

}