<template>
  <h1>This is the home page. I'm in!</h1>
</template>
